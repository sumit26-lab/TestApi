// src/components/ServiceList.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ServiceList = ({ categoryId }) => {
  const [services, setServices] = useState([]);

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const response = await axios.get(`http://localhost:3000/category/${categoryId}/services`);
      setServices(response.data);
    } catch (error) {
      console.error('Error fetching services:', error);
    }
  };

  const handleDelete = async (serviceId) => {
    try {
      await axios.delete(`http://localhost:3000/category/${categoryId}/service/${serviceId}`);
      fetchServices();
    } catch (error) {
      console.error('Error deleting service:', error);
    }
  };

  return (
    <div>
      <h2>Services</h2>
      <ul>
        {services.map((service) => (
          <li key={service.serviceId}>
            {service.serviceName} - Type: {service.type}
            <button onClick={() => handleDelete(service.serviceId)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ServiceList;
