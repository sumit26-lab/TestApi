// src/components/CategoryForm.js

import React, { useState } from 'react';
import axios from 'axios';

const CategoryForm = () => {
  const [categoryName, setCategoryName] = useState('');

  const handleSubmit = async (e) => {
    console.log(categoryName)
    e.preventDefault();
    try {
     let res= await axios.post('http://localhost:9000/api/categories', { name: categoryName });
    
      setCategoryName('');
    } catch (error) {
      console.error('Error creating category:', error);
    }
  };

  return (
    <div>   
      <h1>Add Category</h1>
      <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Category Name"
        value={categoryName}
        onChange={(e) => setCategoryName(e.target.value)}
        required
      />
      <button type="submit">Add Category</button>
    </form>
    </div>

  );
};

export default CategoryForm;
