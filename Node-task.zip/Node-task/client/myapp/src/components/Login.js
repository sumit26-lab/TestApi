// src/components/Login.js

import React, { useState } from 'react';
import axios from 'axios';

const Login = ({setToken}) => {
  const [name, setName] = useState('');


  const handleSubmit = async (e) => {
    console.log("name",name)
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:9000/api/user', name );
      console.log(response)
      const token = response.data.token;
      localStorage.setItem('token', token); // Store token in local storage
      setToken(token); // Pass token to parent component
      setName('');
      
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Email"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      
      <button type="submit">Login</button>
    </form>
  );
};

export default Login;
