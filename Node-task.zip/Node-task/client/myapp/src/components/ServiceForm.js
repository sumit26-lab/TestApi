import React, { useState } from 'react';
import axios from 'axios';

const ServiceForm = ({ categoryId, fetchServices }) => {
  const [serviceName, setServiceName] = useState('');
  const [type, setType] = useState('Normal');
  const [serviceId, setServiceId] = useState(null); // State to hold the created service's id

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`http://localhost:3000/service`, { serviceName, type });
      const createdService = response.data; // Assuming the backend returns the created service object
      setServiceId(createdService.id); // Assuming 'id' is the key for serviceId in the response
      fetchServices();
      setServiceName('');
      setType('Normal');
    } catch (error) {
      console.error('Error creating service:', error);
    }
  };

  return (
    <>
      <h1>ADD Service</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Service Name"
          value={serviceName}
          onChange={(e) => setServiceName(e.target.value)}
          required
        />
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="Normal">Normal</option>
          <option value="VIP">VIP</option>
        </select>
        <button type="submit">Add Service</button>
      </form>
      {serviceId && <p>Created Service ID: {serviceId}</p>}
    </>
  );
};

export default ServiceForm;
