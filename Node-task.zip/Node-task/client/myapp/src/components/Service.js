// Service.js

import React from 'react';
import axios from 'axios';

const Service = ({ category, service, onUpdate, onDelete }) => {
  const handleUpdateService = async (updatedServiceData) => {
    try {
      await axios.put(`http://localhost:9000/api/categories/${category.id}/services/${service.id}`, updatedServiceData);
      onUpdate();
    } catch (error) {
      console.error('Error updating service:', error);
    }
  };

  const handleFormSubmit = async (e, updatedServiceData) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:9000/api/categories/${category.id}/services/${service.id}`, updatedServiceData);
      onUpdate();
    } catch (error) {
      console.error('Error updating service:', error);
    }
  };

  const handleDeleteService = async () => {
    console.log("deleteId",category.id)
    try {
      await axios.delete(`http://localhost:9000/api/service/${category.id}`);;
    } catch (error) {
      console.error('Error deleting service:', error);
    }
  };

  return (
    <li key={service.id}>
      <div>
        <strong>Service Name:</strong> {service.name}
      </div>
      <div>
        <strong>Type:</strong> {service.type}
      </div>
      <form onSubmit={(e) => handleFormSubmit(e, { ...service, name: 'Updated Service Name' })}>
        <input
          type="text"
          value={service.name}
          onChange={(e) => handleUpdateService({ ...service, name: e.target.value })}
        />
        <button type="submit">Update</button>
      </form>
      <button onClick={handleDeleteService}>Delete Service</button>
    </li>
  );
};

export default Service;
