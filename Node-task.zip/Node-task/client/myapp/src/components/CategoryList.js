// CategoryList.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Service from './Service'; // Import the Service component

const CategoryList = () => {
  const [categories, setCategories] = useState([]);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newServiceName, setNewServiceName] = useState('');
  const [newServiceType, setNewServiceType] = useState('Normal'); // Default type or as per your requirement
  const [newServiceDuration, setNewServiceDuration] = useState('');
  const [newServicePrice, setNewServicePrice] = useState('');
  const [newServiceOptionType, setNewServiceOptionType] = useState('Monthly');
  const [addingServiceOption, setAddingServiceOption] = useState(false);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const categoriesResponse = await axios.get('http://localhost:9000/api/categories');
      const categoriesData = categoriesResponse.data;

      // Fetch services and their price options for each category
      const categoriesWithServices = await Promise.all(
        categoriesData.map(async (category) => {
          const servicesResponse = await axios.get(`http://localhost:9000/api/service/${category.id}`);
          const servicesData = servicesResponse.data;

          // Fetch service price options for each service
          const servicesWithPriceOptions = await Promise.all(
            servicesData.map(async (service) => {
              const priceOptionsResponse = await axios.get(`http://localhost:9000/api/service/serviceOption/${category.id}`);
              const priceOptionsData = priceOptionsResponse.data;
              return { ...service, priceOptions: priceOptionsData };
            })
          );

          return { ...category, services: servicesWithPriceOptions };
        })
      );

      setCategories(categoriesWithServices);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handleDeleteCategory = async (categoryId) => {
    try {
      await axios.delete(`http://localhost:9000/api/categories/${categoryId}`);
      fetchCategories();
    } catch (error) {
      console.error('Error deleting category:', error);
    }
  };

  const handleAddServiceAndOption = async (categoryId) => {
    try {
      // Add Service
      const serviceResponse = await axios.post(`http://localhost:9000/api/service`, {
        category_id: categoryId,
        name: newServiceName,
        type: newServiceType
      });
      const newServiceId = serviceResponse.data.id;

      // Add Service Option
      await axios.post(`http://localhost:9000/api/service/serviceOption/${newServiceId}`, {
        duration: newServiceDuration,
        price: newServicePrice,
        type: newServiceOptionType
      });

      fetchCategories();
      setNewServiceName('');
      setNewServiceType('Normal');
      setNewServiceDuration('');
      setNewServicePrice('');
      setNewServiceOptionType('Monthly');
      setAddingServiceOption(false); // Close the form after adding service and option
    } catch (error) {
      console.error('Error adding service and option:', error);
    }
  };

  const updateCategoriesAfterServiceAction = () => {
    fetchCategories();
  };

  return (
    <div>
      <h2>Categories</h2>
      {categories.map((category) => (
        <div key={category.id}>
          <h3>{category.name}</h3>
          {category.services.length > 0 ? (
            <ul>
              {category.services.map((service) => (
                <div key={service.id}>
                  <Service
                    category={category}
                    service={service}
                    onUpdate={updateCategoriesAfterServiceAction}
                    onDelete={updateCategoriesAfterServiceAction}
                  />
                  {service.priceOptions.length > 0 && (
                    <ul>
                      {service.priceOptions.map((option) => (
                        <li key={option.id}>
                          Duration: {option.duration}, Price: {option.price}, Type: {option.type}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </ul>
          ) : (
            <div>
              <p>No services found.</p>
            </div>
          )}
          <div>
            {!addingServiceOption && (
              <button onClick={() => setAddingServiceOption(true)}>Add Service and Option</button>
            )}
            {addingServiceOption && (
              <div>
                <input
                  type="text"
                  placeholder="Service Name"
                  value={newServiceName}
                  onChange={(e) => setNewServiceName(e.target.value)}
                />
                <select
                  value={newServiceType}
                  onChange={(e) => setNewServiceType(e.target.value)}
                >
                  <option value="Normal">Normal</option>
                  {/* Add other type options as needed */}
                </select>
                <input
                  type="text"
                  placeholder="Duration"
                  value={newServiceDuration}
                  onChange={(e) => setNewServiceDuration(e.target.value)}
                />
                <input
                  type="text"
                  placeholder="Price"
                  value={newServicePrice}
                  onChange={(e) => setNewServicePrice(e.target.value)}
                />
                <select
                  value={newServiceOptionType}
                  onChange={(e) => setNewServiceOptionType(e.target.value)}
                >
                  <option value="Monthly">Monthly</option>
                  {/* Add other type options as needed */}
                </select>
                <button onClick={() => handleAddServiceAndOption(category.id)}>Add Service and Option</button>
                <button onClick={() => setAddingServiceOption(false)}>Cancel</button>
              </div>
            )}
          </div>
          <button onClick={() => handleDeleteCategory(category.id)}>Delete Category</button>
        </div>
      ))}
    </div>
  );
};

export default CategoryList;
