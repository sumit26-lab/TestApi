// src/App.js

import React, { useState } from 'react';
import Login from './components/Login';
import CategoryForm from './components/CategoryForm';
import CategoryList from './components/CategoryList';
import ServiceForm from './components/ServiceForm';
import ServiceList from './components/ServiceList';
import axios from 'axios';

function App() {
  const [token, setToken] = useState(null);

  React.useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setToken(storedToken);
    }
  }, []);

  axios.interceptors.request.use(
    (config) => {
      if (token) {
        config.headers.Authorization = `${token}`;
      }
      return config;
    },
    (error) => {
      return Promise.reject(error);
    }
  );

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
  };

  return (
    <div className="App">
      <h1>Service Management</h1>
      {token ? (
        <>
          <button onClick={handleLogout}>Logout</button>
          <CategoryForm />
          <CategoryList />
           {/* <ServiceForm /> */}
          
        </>
      ) : (
        <Login setToken={setToken} />
      )}
    </div>
  );
}

export default App;
