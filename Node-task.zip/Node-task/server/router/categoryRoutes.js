// routes/categoryRoutes.js
const express = require('express');
const router = express.Router();
const categoryController = require('../controler/categoryController');
const auth = require('../middleware/auth'); // Middleware for JWT authentication

// CRUD routes for categories
router.post('/',  auth,categoryController.createCategory);
router.get('/', auth,categoryController.getCategories);
router.put('/:id', auth, categoryController.updateCategory);
router.delete('/:categoryId', auth,categoryController.deleteCategory);

module.exports = router;
