const express = require('express');
const router = express.Router();
const userController = require('../controler/userController');

// CRUD routes for categories
router.post('/',  userController.postLogin);
module.exports =router
