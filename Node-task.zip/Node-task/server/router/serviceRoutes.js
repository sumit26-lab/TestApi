// routes/serviceRoutes.js

const express = require('express');
const router = express.Router();
const serviceController = require('../controler/ServiceControler');
const auth = require('../middleware/auth'); // Middleware for JWT authentication

// CRUD routes for services in categories
router.post('/', auth, serviceController.createService);
router.get('/', auth,serviceController.getServices);
router.put('/:id', auth, serviceController.updateService);
router.get('/:id',auth,serviceController.getServicesInCategory)
router.delete('/:id',auth,serviceController.DeletService)

//CRUD routes for option service
router.post('/serviceOption/:serviceId', auth,serviceController.createServicePriceOption)
router.get('/serviceOption/:serviceId', auth,serviceController.getAllServicePriceOptions)
router.put('/serviceOption/:serviceId/:servicePriceOptionId', auth,serviceController.updateServicePriceOption)
router.delete('/serviceOption/:serviceId/:servicePriceOptionId', auth,serviceController.deleteServicePriceOption)

module.exports = router;
