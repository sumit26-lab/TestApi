const {Client} =require('pg')

const pool= new Client({
    port:5432,
    user:'postgres',
    host:'localhost',
    database:"Test-code",
    password: "12345"
})
pool.connect().then(()=>console.log('data base Connected')).catch(error=>{
    console.log(`database Connetion faled`,error)
})
module.exports=pool