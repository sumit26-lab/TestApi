const express= require('express')
const app= express()
const bodyparser= require('body-parser')
const pool= require('./utill/dbConnect')
const categoriesRout= require('./router/categoryRoutes')
const userRoute= require('./router/loginRoute')
const serviceRoutes= require('./router/serviceRoutes')
app.use(bodyparser.urlencoded({extended:false}))

const cors = require('cors');
app.use(cors());
app.use(bodyparser.json())
app.set('view engine','ejs')
app.use('/api/categories',categoriesRout)
app.use('/api/user',userRoute)
app.use('/api/service',serviceRoutes)




app.listen(9000,()=>{
    console.log('Server will start on 9000')
})