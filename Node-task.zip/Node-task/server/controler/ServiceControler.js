// serviceController.js
const pool = require('../utill/dbConnect');

// Create a new service
exports.createService = async (req, res) => {
  const { name, category_id ,type} = req.body;
  if (type !== 'Normal' && type !== 'VIP') {
    return res.status(400).json({ msg: 'Invalid type. Allowed values are "Normal" or "VIP".' });
  }

  try {
    const query = 'INSERT INTO services (name, category_id,type) VALUES ($1, $2,$3) RETURNING *';
    const result = await pool.query(query, [name, category_id,type]);

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Get all services
exports.getServices = async (req, res) => {
  try {
    const query = 'SELECT * FROM services';
    const result = await pool.query(query);

    res.json(result.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Update a service
exports.updateService = async (req, res) => {
  const serviceId = req.params.id;
  const { name, categoryId } = req.body;

  try {
    const query = 'UPDATE services SET name = $1, category_id = $2 WHERE id = $3 RETURNING *';
    const result = await pool.query(query, [name, categoryId, serviceId]);

    if (result.rowCount === 0) {
      return res.status(404).json({ msg: 'Service not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};




// GET /category/:categoryId/services - Get all services in a category
exports.getServicesInCategory = async (req, res) => {
  const id = req.params.id;
  console.log(id)

  try {
    const services = await pool.query('SELECT * FROM services WHERE category_id = $1', [id]);
    res.json(services.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Delete empty category (with no services)
exports.DeletService = async (req, res) => {
  const id = parseInt(req.params.id,10);

  try {
    // Check if category has services
    const servicesCount = await pool.query('SELECT COUNT(*) FROM services WHERE category_id = $1', [id]);
    if (servicesCount.rows[0].count > 0) {
      const deletedCategory = await pool.query('DELETE FROM services WHERE category_id = $1 RETURNING *', [id]);
      console.log(deletedCategory.rowCount)
      res.json({ message: 'Category deleted successfully' });
    }
    // Delete category 
   
    else{
      return res.status(404).json({ message: 'Category not found' });
    }
    
  }catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
  
}
exports.createServicePriceOption = async (req, res) => {
  console.log("apihit")
  const {  serviceId } = req.params;
  const { duration, price, type } = req.body;
  const query = `
      INSERT INTO service_price_options (service_id, duration, price, type)
      VALUES ($1, $2, $3, $4)
      RETURNING *
  `;
  try {
      const { rows } = await pool.query(query, [serviceId, duration, price, type]);
      res.status(201).json(rows[0]);
  } catch (error) {
      res.status(500).json({ error: error.message });
  }
};

// Get all service price options for a service
exports.getAllServicePriceOptions = async (req, res) => {
  const { serviceId } = req.params;
  const query = 'SELECT * FROM service_price_options WHERE service_id = $1';
  try {
      const { rows } = await pool.query(query, [serviceId]);
      res.status(200).json(rows);
  } catch (error) {
      res.status(500).json({ error: error.message });
  }
};

// Update a service price option
exports.updateServicePriceOption = async (req, res) => {
    const {  serviceId, servicePriceOptionId } = req.params;
    const { duration, price, type } = req.body;
  
    const query = `
        UPDATE service_price_options
        SET duration = $1, price = $2, type = $3
        WHERE id = $4 AND service_id = $5
        RETURNING *
    `;
    try {
        const { rows } = await pool.query(query, [duration, price, type, servicePriceOptionId, serviceId]);
        if (rows.length === 0) {
            res.status(404).json({ error: 'Service price option not found' });
        } else {
            res.status(200).json(rows[0]);
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Delete a service price option
exports.deleteServicePriceOption = async (req, res) => {
  const { serviceId, servicePriceOptionId } = req.params;
  const query = `
      DELETE FROM service_price_options
      WHERE id = $1 AND service_id = $2
      RETURNING *
  `;
  try {
      const { rows } = await pool.query(query, [servicePriceOptionId, serviceId]);
      if (rows.length === 0) {
          res.status(404).json({ error: 'Service price option not found' });
      } else {
          res.status(204).send(true);
      }
  } catch (error) {
      res.status(500).json({ error: error.message });
  }
};