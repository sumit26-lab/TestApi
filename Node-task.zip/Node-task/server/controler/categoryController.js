// controllers/categoryController.js
const pool = require('../utill/dbConnect');

// Create a new category
exports.createCategory = async (req, res) => {
  const { name } = req.body;


  try {
    const query = 'INSERT INTO categories (name) VALUES ($1) RETURNING *';
    const result = await pool.query(query, [name]);

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Get all categories
exports.getCategories = async (req, res) => {
  try {
    const query = 'SELECT * FROM categories';
    const result = await pool.query(query);

    res.json(result.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Update a category
exports.updateCategory = async (req, res) => {
  const categoryId = req.params.id;
  const { name } = req.body;

  try {
    const query = 'UPDATE categories SET name = $1 WHERE id = $2 RETURNING *';
    const result = await pool.query(query, [name, categoryId]);

    if (result.rowCount === 0) {
      return res.status(404).json({ msg: 'Category not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Delete a category
exports. deleteCategory = async (req, res) => {
  
  const categoryId = req.params.categoryId;
  console.log(categoryId)
  // Check if the category has services before deleting
  const serviceQuery = 'SELECT COUNT(*) FROM services WHERE category_id = $1';
  const deleteQuery = 'DELETE FROM categories WHERE id = $1 RETURNING *';
  const categoriesDelete=' DELETE FROM services WHERE category_id = $1 RETURNING *'
  const servicedelter='DELETE FROM services WHERE service_id = $1 RETURNING *'
  const categories='SELECT COUNT(*) FROM categories WHERE category_id = $1'
  try {
    const { rows: CategoryCount } = await pool.query(categories, [categoryId])
      const { rows: serviceCount } = await pool.query(serviceQuery, [categoryId]);
      if(CategoryCount[0]>0){
        await pool.query(deleteQuery, [categoryId])
      }
      if (serviceCount[0].count > 0 ) {
         await pool.query(deleteQuery, [categoryId])
         await pool.query(categoriesDelete,[categoryId])
         await pool.query(servicedelter,[categoryId])
        
          res.status(201).json("ok");
      } else {
          
          if (rows.length === 0) {
              res.status(404).json({ error: 'Category not found' });
          } else {
            console.log("ok")
              res.status(204).send("ok");
          }
      }
  } catch (error) {
      res.status(500).json({ error: error.message });
  }
};
