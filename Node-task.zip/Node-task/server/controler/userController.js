
const jwt = require('jsonwebtoken');
exports.postLogin=('/', (req, res) => {
    const { username, password } = req.body;
    // Implement your login logic here to authenticate the user
  
    // For demo purposes, generating a token without actual authentication
    const token = jwt.sign({ username }, 'your_secret_key', { expiresIn: '1h' });
    res.json({ token });
  });
